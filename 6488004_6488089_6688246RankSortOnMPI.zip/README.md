# MUICT2023 ITCS443 Group Assignment
ITCS443 Group Assignment 1 Section 3
## Members
 - 6488004 Kittipich Aiumbhornsin
 - 6488089 Pattaravit Suksri
 - 6688246 Mohammed Borhan Hussaini
## Instruction of how to run the program
 - Extract the zip file.
 - On the terminal, change directory to where the zip file has been extracted using command `cd` and follow with the directory path.
 - List the files in the directory by using command `ls` and find file name `parallelRankSortMPI2023.c` to make sure that the source code is available.
 - On the terminal type command `mpicc -o parallelRankSortMPI2023 parallelRanksortMPI2023.c` and click __enter__, to compile the program.
 - Then, to run the program, on the same terminal type command `mpirun -np 2 parallelRankSortMPI2023` and click __enter__. (Note: For running on 2 nodes/processors. If would like to on different number, replace the number `2` in the command with that number.)
 - After that, it will prompt to get the amount of number that to be generated and sort, key in only the number in integer you want
 - Wait and see the cool result!
 - Thank you!
